plugins {
    kotlin("jvm")
    kotlin("kapt")
    id("com.squareup.anvil")
}

dependencies {
    implementation(deps.kotlin.coroutines.jvm)
    api(deps.modules.inject.core(this))
    api(deps.dagger.runtime)
    kapt(deps.dagger.compiler)
}
