plugins {
    id("java-library")
    kotlin("jvm")
    id("com.squareup.anvil")
}

dependencies {
    api(deps.modules.inject.core(this))
}