package ${PACKAGE_NAME}.${FEATURE_NAME}.api.inject

import ${PACKAGE_NAME}.${FEATURE_NAME}.api.${FEATURE_NAME_UPPER_CASE}ApiService
import com.goat.inject.ApplicationScope
import com.squareup.anvil.annotations.ContributesTo
import dagger.Module
import dagger.Provides
import retrofit2.Retrofit
import retrofit2.create
import javax.inject.Singleton

@Module
@ContributesTo(ApplicationScope::class)
object ${FEATURE_NAME_UPPER_CASE}ApiModule {
    @Provides
    @Singleton
    fun provide${FEATURE_NAME_UPPER_CASE}ApiService(retrofit: Retrofit): ${FEATURE_NAME_UPPER_CASE}ApiService = retrofit.create()
}
