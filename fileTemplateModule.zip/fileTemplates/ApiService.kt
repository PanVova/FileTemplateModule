package ${PACKAGE_NAME}.${FEATURE_NAME}.api

interface ${FEATURE_NAME_UPPER_CASE}ApiService {
}
