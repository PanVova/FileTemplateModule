package ${PACKAGE_NAME}.${FEATURE_NAME}.api.inject

import ${PACKAGE_NAME}.${FEATURE_NAME}.api.${FEATURE_NAME_UPPER_CASE}ApiService
import com.goat.inject.ApplicationScope
import com.squareup.anvil.annotations.ContributesTo

#parse("File Header.java")
@ContributesTo(ApplicationScope::class)
interface ${FEATURE_NAME_UPPER_CASE}ApiComponent {
    val apiService: ${FEATURE_NAME_UPPER_CASE}ApiService
}
