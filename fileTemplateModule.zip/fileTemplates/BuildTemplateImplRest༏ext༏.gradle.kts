plugins {
    id("java-library")
    kotlin("jvm")
    kotlin("kapt")
    id("com.squareup.anvil")
}

dependencies {
    api(deps.modules.inject.core(this))
    api(deps.modules.network.core(this))

    kapt(deps.dagger.compiler)
    kapt(deps.moshi.compiler)
}